#include "pch.h"
#include "DXGICapture.h"
#include <windows.h>
#include <psapi.h>
#include <iostream>
#ifdef DXCAPTRUE


ID3D11DeviceContext* g_d3d_context = NULL;
ID3D11Device* g_d3d_device = NULL;
HANDLE hProcess = NULL;
__int64 runing_flag = 0;
int handle_num = 0;

winrt::Windows::Graphics::SizeInt32 m_lastSize;
winrt::com_ptr<ID3D11Texture2D> user_texture{ nullptr };
winrt::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice device;
MyFrameArrivedEventHandle g_myEventHandle;
struct __declspec(uuid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"))
    IDirect3DDxgiInterfaceAccess : ::IUnknown
{
    virtual HRESULT __stdcall GetInterface(GUID const& id, void** object) = 0;
};

//auto  handler = [&](const winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool& frame_pool, auto&)
void handler(winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool frame_pool, winrt::Windows::Foundation::IInspectable const& b)
{

   /* PROCESS_MEMORY_COUNTERS pmc;
    if (GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc))) {
        std::cout << "Peak Working Set Size: " << pmc.PeakWorkingSetSize << " bytes" << std::endl;
    }*/
    winrt::Windows::Graphics::Capture::Direct3D11CaptureFrame frame = frame_pool.TryGetNextFrame();

    auto frameContentSize = frame.ContentSize();
    winrt::com_ptr<IDirect3DDxgiInterfaceAccess> access = frame.Surface().as<IDirect3DDxgiInterfaceAccess>();

    winrt::com_ptr<ID3D11Texture2D> texture;
    access->GetInterface(winrt::guid_of<ID3D11Texture2D>(), texture.put_void());

    //resize capture
    if (frameContentSize.Width != m_lastSize.Width ||
        frameContentSize.Height != m_lastSize.Height)
    {
        if (user_texture) {

            user_texture = nullptr;
        }
        m_lastSize = frameContentSize;
        // The thing we have been capturing has changed size.
        // We need to resize our swap chain first, then blit the pixels.
        // After we do that, retire the frame and then recreate our frame pool.
        frame_pool.Recreate(
            device,
            winrt::Windows::Graphics::DirectX::DirectXPixelFormat::B8G8R8A8UIntNormalized,
            2,
            m_lastSize);

        return;
    }



    D3D11_TEXTURE2D_DESC captured_texture_desc;
    texture->GetDesc(&captured_texture_desc);


   
    if (user_texture==nullptr) {


        captured_texture_desc.Usage = D3D11_USAGE_STAGING;
        captured_texture_desc.BindFlags = 0;
        captured_texture_desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        captured_texture_desc.MiscFlags = 0;
        winrt::check_hresult(g_d3d_device->CreateTexture2D(&captured_texture_desc, nullptr, user_texture.put()));
       

    }

    g_d3d_context->Flush();
    g_d3d_context->CopyResource(user_texture.get(), texture.get());
    g_d3d_context->Flush();  // Ensures all pending GPU commands are executed


    //Sleep(100);FPS Ϊ10֡ʱ�����Ա����ڴ�й©�������Կ�����д���ٶȴ���CPU�ڴ��ͷ��ٶȣ��ͻ���ɳ������ڴ�����

    D3D11_MAPPED_SUBRESOURCE resource;
    winrt::check_hresult(g_d3d_context->Map(user_texture.get(), NULL, D3D11_MAP_READ, 0, &resource));
    g_d3d_context->Flush();  // Ensures all pending GPU commands are executed
    
    g_d3d_context->Unmap(user_texture.get(), NULL);

    g_d3d_context->Flush();  // Ensures all pending GPU commands are executed



    //std::vector<UCHAR> bytes;
    size_t height = captured_texture_desc.Height;
    size_t width = captured_texture_desc.Width;

    size_t rowPitch = resource.RowPitch;
    size_t rSize = rowPitch * height;
    //bytes.resize(rSize);

      /*  std::vector<cv::Mat> b;
        cv::Mat dst;
        dst.create(cv::Size(height, width), CV_MAKETYPE(CV_8U, 3));*/

    if (resource.pData)
    {

        //memcpy(bytes.data(), resource.pData, bytes.size());
        UCHAR* img_array = (UCHAR*)resource.pData;

        PyImagePackage pk = { img_array,height,width,rowPitch,rSize };
        //UCHAR temp[255];
        //PyImagePackage pk = { temp,0,0,0,0 };
        if (g_myEventHandle&& runing_flag) {
            runing_flag = g_myEventHandle(&pk);
            //printf("capt python do:%d\n", runing_flag);
        }
        else
        {
            //printf("capt do:%d\n", runing_flag);
            runing_flag = 0;
        }

    }


};

//���ִ�������ʽ��ͼ����
void DXGICapture::StartCapturewindow(HWND window_handle, MyFrameArrivedEventHandle myEventHandle)
{
    hProcess = GetCurrentProcess();
    // Init COM
    init_apartment(winrt::apartment_type::single_threaded);

    // Create Direct 3D Device
    winrt::com_ptr<ID3D11Device> d3d_device;

    winrt::check_hresult(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        nullptr, 0, D3D11_SDK_VERSION, d3d_device.put(), nullptr, nullptr));



    const auto dxgiDevice = d3d_device.as<IDXGIDevice>();
    {
        winrt::com_ptr<IInspectable> inspectable;
        winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice.get(), inspectable.put()));
        device = inspectable.as<winrt::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice>();
    }


    auto idxgi_device2 = dxgiDevice.as<IDXGIDevice2>();
    winrt::com_ptr<IDXGIAdapter> adapter;
    winrt::check_hresult(idxgi_device2->GetParent(winrt::guid_of<IDXGIAdapter>(), adapter.put_void()));
    winrt::com_ptr<IDXGIFactory2> factory;
    winrt::check_hresult(adapter->GetParent(winrt::guid_of<IDXGIFactory2>(), factory.put_void()));

    ID3D11DeviceContext* d3d_context = nullptr;
    d3d_device->GetImmediateContext(&d3d_context);


    RECT rect{};
    DwmGetWindowAttribute(window_handle, DWMWA_EXTENDED_FRAME_BOUNDS, &rect, sizeof(RECT));
    //ȷ������û�ж���ı߿����Ը��š�����ʹ��DwmExtendFrameIntoClientArea API���������ڱ߿�
    MARGINS margins = {0, 0, 0, 0};
    DwmExtendFrameIntoClientArea(window_handle, &margins);
    m_lastSize = winrt::Windows::Graphics::SizeInt32{ rect.right - rect.left, rect.bottom - rect.top };

    winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool m_frame_pool{ nullptr };
    m_frame_pool = winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool::Create(
            device,
            winrt::Windows::Graphics::DirectX::DirectXPixelFormat::B8G8R8A8UIntNormalized,
            2,
            m_lastSize);

    // Obtaining the factory
    auto interopFactory = winrt::get_activation_factory<winrt::Windows::Graphics::Capture::GraphicsCaptureItem,IGraphicsCaptureItemInterop>();

    // Create an IGraphicsCaptureItemInterop object
    /*auto activation_factory = winrt::get_activation_factory<winrt::Windows::Graphics::Capture::GraphicsCaptureItem>();
    winrt::com_ptr<IGraphicsCaptureItemInterop> interop_factory = activation_factory.as<IGraphicsCaptureItemInterop>();*/
    
  
  
   
    winrt::Windows::Graphics::Capture::GraphicsCaptureItem capture_item = { nullptr };
    interopFactory->CreateForWindow(window_handle, winrt::guid_of<ABI::Windows::Graphics::Capture::IGraphicsCaptureItem>(),
        winrt::put_abi(capture_item));
    winrt::Windows::Graphics::Capture::GraphicsCaptureSession session = m_frame_pool.CreateCaptureSession(capture_item);
    


    
    winrt::event_token token = m_frame_pool.FrameArrived(handler);
    //winrt::com_ptr<ID3D11Texture2D> temp_texture2;
    //texture_p = temp_texture2.put();




    session.StartCapture();
    session.IsCursorCaptureEnabled(false);
    runing_flag = 1;
    handle_num = 0;
    g_d3d_device = d3d_device.get();
    g_d3d_context = d3d_context;
    g_myEventHandle = myEventHandle;

     // Message pump
    MSG message;
 
    while (runing_flag)
    {
       
       if (PeekMessage(&message, nullptr, 0, 0, PM_REMOVE) > 0)
       {
            DispatchMessage(&message);
       }
       else {
           Sleep(1);
       }

    }


    session.Close();
    m_frame_pool.Close();
    d3d_context->Release();
    capture_item = nullptr;  // Release capture_item
    g_myEventHandle = NULL;
    user_texture = nullptr;



}

//�ɰ��DX11��ͼ����
int DXGICapture::StartDXCaputreWindow(HWND gameWindow, MyFrameArrivedEventHandle myEventHandle)
{
    HRESULT hr;
    // ��ʼ�� DirectX �豸���豸������
    Microsoft::WRL::ComPtr<ID3D11Device> device;
    Microsoft::WRL::ComPtr<ID3D11DeviceContext> deviceContext;
    D3D_FEATURE_LEVEL featureLevel;
    Microsoft::WRL::ComPtr<IDXGISwapChain> swapChain;

    static const D3D_DRIVER_TYPE driverTypes[] = {
          D3D_DRIVER_TYPE_HARDWARE,
          D3D_DRIVER_TYPE_WARP,
          D3D_DRIVER_TYPE_REFERENCE
    };

    static const D3D_FEATURE_LEVEL featureLevels[] = {
        D3D_FEATURE_LEVEL_12_0,
        D3D_FEATURE_LEVEL_11_0,
        D3D_FEATURE_LEVEL_10_1,
        D3D_FEATURE_LEVEL_10_0,
        D3D_FEATURE_LEVEL_9_1
    };


    // ��ȡ��Ϸ���ڵĴ�С
    RECT windowRect;
    GetClientRect(gameWindow, &windowRect);
    UINT width = windowRect.right - windowRect.left;
    UINT height = windowRect.bottom - windowRect.top;
    DXGI_SWAP_CHAIN_DESC swapChainDesc; // ���滻Ϊʵ�ʵĽ���������
    ZeroMemory(&swapChainDesc, sizeof(swapChainDesc));
    swapChainDesc.BufferCount = 2;                             // Number of back buffers
    swapChainDesc.BufferDesc.Width = width;                    // Width of the back buffer
    swapChainDesc.BufferDesc.Height = height;                  // Height of the back buffer
    swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;  // Back buffer format
    swapChainDesc.BufferDesc.RefreshRate.Numerator = 60;
    swapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
    swapChainDesc.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    swapChainDesc.OutputWindow = gameWindow;                         // Handle to the window to render to
    swapChainDesc.SampleDesc.Count = 1;                        // Number of samples for multisampling
    swapChainDesc.SampleDesc.Quality = 0;
    swapChainDesc.Windowed = TRUE;
    swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    DXGI_FORMAT format = swapChainDesc.BufferDesc.Format;

    for (const auto& driverType : driverTypes) {

        hr = D3D11CreateDeviceAndSwapChain(
            nullptr,                            // Specify the adapter (use nullptr for the default adapter)
            driverType,           // Use hardware acceleration
            nullptr,                            // Use no software rasterizer
            D3D11_CREATE_DEVICE_DEBUG,                                  // No flags
            featureLevels,                      // Array of feature levels
            static_cast<UINT>(std::size(featureLevels)),                   // Number of feature levels in the array
            D3D11_SDK_VERSION,                  // SDK version
            &swapChainDesc,                     // Swap chain description
            swapChain.GetAddressOf(),           // Output swap chain pointer
            device.GetAddressOf(),              // Output device pointer
            &featureLevel,                      // Output feature level
            deviceContext.GetAddressOf()        // Output device context pointer
        );
        if (SUCCEEDED(hr)) {
            printf("�Ѿ��ҵ������豸");
            break;
        }
        else {
            printf("����D3D11CreateDeviceAndSwapChainʧ�ܵ����%x", hr);
        }
        //device.Get()->Release();
        //deviceContext.Get()->Release();
    }
    if (FAILED(hr))
    {

        printf("����D3D11CreateDeviceAndSwapChainʧ�ܵ����%x", hr);
        return NULL;
    }
    UINT formatSupport;
    hr = device->CheckFormatSupport(format, &formatSupport);
    if (!(formatSupport & D3D11_FORMAT_SUPPORT_TEXTURE2D))
    {
        printf("��ʽ����֧�֣�����������ʽ������豸������ʽ");
        return NULL;
    }

    // ��ȡ DXGI �豸
    Microsoft::WRL::ComPtr<IDXGIDevice> dxgiDevice;
    hr = device.As(&dxgiDevice);
    if (FAILED(hr))
    {

        printf("������ȡ DXGI �豸ʧ�ܵ����");
        return NULL;
    }

    // ��ȡ DXGI ������
    Microsoft::WRL::ComPtr<IDXGIAdapter> dxgiAdapter;
    hr = dxgiDevice->GetAdapter(dxgiAdapter.GetAddressOf());
    if (FAILED(hr))
    {

        printf("������ȡ DXGI ������ʧ�ܵ����");
        return NULL;
    }
    // Create a DXGI factory
    Microsoft::WRL::ComPtr < IDXGIFactory> pFactory = nullptr;
    hr = CreateDXGIFactory(__uuidof(IDXGIFactory), reinterpret_cast<void**>(pFactory.GetAddressOf()));

    // Enumerate adapters
    std::vector< Microsoft::WRL::ComPtr <IDXGIAdapter>> adapters;
    Microsoft::WRL::ComPtr <IDXGIAdapter> pAdapter = nullptr;
    UINT adapterIndex = 0;
    Microsoft::WRL::ComPtr<IDXGIOutput> dxgiOutput;


    if (FAILED(hr)) {
        printf("����EnumOutputsʧ�ܵ����");
        return NULL;
    }

    while (pFactory->EnumAdapters(adapterIndex, pAdapter.GetAddressOf()) != DXGI_ERROR_NOT_FOUND)
    {
        adapters.push_back(pAdapter);
        adapterIndex++;
    }
    // Enumerate outputs for each adapter
    for (Microsoft::WRL::ComPtr < IDXGIAdapter> pCurrAdapter : adapters)
    {
        std::vector< Microsoft::WRL::ComPtr <IDXGIOutput>> outputs;
        Microsoft::WRL::ComPtr <IDXGIOutput> pOutput = nullptr;
        UINT outputIndex = 0;

        while (pCurrAdapter->EnumOutputs(outputIndex, pOutput.GetAddressOf()) != DXGI_ERROR_NOT_FOUND)
        {
            outputs.push_back(pOutput);
            outputIndex++;
        }

        // Now you can iterate through the outputs and match the window handle
        for (Microsoft::WRL::ComPtr <IDXGIOutput> pCurrOutput : outputs)
        {
            DXGI_OUTPUT_DESC outputDesc;
            pCurrOutput->GetDesc(&outputDesc);

            // Check if the window handle matches the desired window
            if (outputDesc.Monitor == MonitorFromWindow(gameWindow, MONITOR_DEFAULTTONEAREST))
            {
                dxgiOutput = pCurrOutput;
                // Found the desired output for the window
                // Use pCurrOutput (IDXGIOutput interface) as needed
                //break;
            }

            // Release the current output since it's not the desired one
            pCurrOutput->Release();
        }

        // Release the outputs vector
        /*for (Microsoft::WRL::ComPtr <IDXGIOutput> pCurrOutput : outputs)
        {
            pCurrOutput->Release();
        }
        outputs.clear();*/

        // Release the current adapter
        pCurrAdapter->Release();
    }

    // Release the DXGI factory
    pFactory->Release();
    //hr = dxgiAdapter->EnumOutputs(0, dxgiOutput.GetAddressOf());
    hr = swapChain.Get()->GetContainingOutput(dxgiOutput.GetAddressOf());

    Microsoft::WRL::ComPtr<IDXGIResource> desktopResource;
    hr = E_FAIL;
    __int64 runing_flag = 1;
    while (runing_flag) {
        DXGI_OUTDUPL_FRAME_INFO fi{};
        const int timeoutMsec = 500; // milliseconds

        Microsoft::WRL::ComPtr<IDXGIOutput1> dxgiOutput1;
        hr = dxgiOutput->QueryInterface(
            __uuidof(IDXGIOutput1),
            (void**)dxgiOutput1.GetAddressOf()
        );
        if (FAILED(hr)) {
            printf("����dxgiOutput1ʧ�ܵ����");
            return NULL;
        }
        Microsoft::WRL::ComPtr<IDXGIOutputDuplication> outputDuplication;
        hr = dxgiOutput1->DuplicateOutput(device.Get(), outputDuplication.GetAddressOf());
        if (FAILED(hr)) {
            printf("����DuplicateOutputʧ�ܵ����");
            return NULL;
        }
        hr = outputDuplication->AcquireNextFrame(timeoutMsec, &fi, desktopResource.GetAddressOf());
        if (SUCCEEDED(hr) && (fi.LastPresentTime.QuadPart == 0)) {
            // If AcquireNextFrame() returns S_OK and
            // fi.LastPresentTime.QuadPart == 0, it means
            // AcquireNextFrame() didn't acquire next frame yet.
            // We must wait next frame sync timing to retrieve
            // actual frame data.
            //
            // Since method is successfully completed,
            // we need to release the resource and frame explicitly.
            desktopResource->Release();
            outputDuplication->ReleaseFrame();
            Sleep(1);
            continue;
        }
        else if (SUCCEEDED(hr)) {
            Microsoft::WRL::ComPtr<ID3D11Texture2D> acquiredDesktopImage;
            hr = desktopResource->QueryInterface(
                __uuidof(ID3D11Texture2D),
                (void**)acquiredDesktopImage.GetAddressOf()
            );
            if (FAILED(hr)) {
                printf("����QueryInterfaceʧ�ܵ����");
                return NULL;
            }
            Microsoft::WRL::ComPtr < ID3D11Texture2D> pBackBuffer;
            swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(pBackBuffer.GetAddressOf()));
            D3D11_TEXTURE2D_DESC desc = {};
            pBackBuffer->GetDesc(&desc);

            DXGI_OUTDUPL_DESC lOutputDesc;
            // Create GUI drawing texture
            outputDuplication->GetDesc(&lOutputDesc);

            // Create CPU access texture
            Microsoft::WRL::ComPtr<ID3D11Texture2D> pStagingTexture;
            desc.Width = lOutputDesc.ModeDesc.Width;
            desc.Height = lOutputDesc.ModeDesc.Height;
            desc.Format = lOutputDesc.ModeDesc.Format;
            desc.ArraySize = 1;

            desc.SampleDesc.Count = 1;
            desc.SampleDesc.Quality = 0;
            desc.MipLevels = 1;
            desc.BindFlags = 0;
            desc.MiscFlags = 0;
            desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ | D3D11_CPU_ACCESS_WRITE;
            desc.Usage = D3D11_USAGE_STAGING;
            device->CreateTexture2D(&desc, NULL, pStagingTexture.GetAddressOf());

            // ����̨���������Ƶ���ͼĿ������
            deviceContext->CopyResource(pStagingTexture.Get(), acquiredDesktopImage.Get());
            D3D11_MAPPED_SUBRESOURCE res;
            UINT subresource = D3D11CalcSubresource(0, 0, 0);
            hr = deviceContext->Map(pStagingTexture.Get(), subresource, D3D11_MAP_READ_WRITE, 0, &res);

            if (res.pData)
            {
                std::vector<byte> bytes;
                size_t height = desc.Height;
                size_t with = desc.Width;
                size_t rowPitch = res.RowPitch;
                size_t rSize = rowPitch * height;
                bytes.resize(rowPitch * height);
                memcpy(bytes.data(), res.pData, bytes.size());

             
                PyImagePackage pk = { bytes.data() ,height,width,rowPitch,rSize};
                if (myEventHandle) {
                    runing_flag = myEventHandle(&pk);
                }
                else
                {
                    runing_flag = 0;
                }
            }
            Sleep(1);
        }


    }


    return NULL;

}

#endif
