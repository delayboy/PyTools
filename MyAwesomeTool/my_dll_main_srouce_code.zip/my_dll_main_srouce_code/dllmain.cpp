// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "DXGICapture.h"
#include <TlHelp32.h>
#include <map>

typedef struct _HookPackage {
	bool keyEventType;
	DWORD32 code;
	__int64 wParam;
}HookPackage;
typedef LRESULT(CALLBACK* PYHOOKPROC)(HookPackage*);
typedef __int64 (*PAINT_CALLBACK)(HDC hdc);
typedef struct _FindWinPackage {
	HWND hwnd;
	const char* winName;
}FindWinPackage;

PYHOOKPROC pyhookProc = NULL;
PAINT_CALLBACK pyPaintCallback = NULL;
HINSTANCE hInstance = NULL;
HHOOK g_Hook = NULL,m_Hook=NULL;
DWORD keyCode = 0;
HANDLE keyCodeArrivedEvent = NULL;
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam);
extern "C" __declspec(dllexport) void calculateScreenScale(double* horzScale, double* vertScale);
extern "C" __declspec(dllexport) HHOOK registerEventHook(int keyHook, bool doRegister);
extern "C" __declspec(dllexport)  size_t* GetBmpInfo(HBITMAP hBmp, size_t info[4]);
double horzScale = 0, vertScale = 0;
HKL hkl;
HWND g_wnd = NULL;
BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		// Set DPI awareness context before creating the window
		SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_SYSTEM_AWARE);
		keyCodeArrivedEvent = CreateEventA(NULL, FALSE, TRUE, "keyCodeArrivedEvent");
		if (keyCodeArrivedEvent)ResetEvent(keyCodeArrivedEvent);
		hInstance = GetModuleHandle(NULL);
		hkl = GetKeyboardLayout(0);
		calculateScreenScale(&horzScale, &vertScale);
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		registerEventHook(0, false);
		registerEventHook(1, false);
		keyCodeArrivedEvent = NULL;
		horzScale = 0, vertScale = 0;
		break;
	}
	return TRUE;
}

extern "C" __declspec(dllexport) void MySetForegroundWindow(HWND hwnd)
{
	
	SetForegroundWindow(hwnd);

}

extern "C" __declspec(dllexport) void calculateScreenScale(double* horzScale, double* vertScale)
{
	// ��ȡ���ڵ�ǰ��ʾ�ļ�����
	HWND hWnd = GetDesktopWindow();//������Ҫ�����滻���Լ�����ľ�� 
	HMONITOR hMonitor = MonitorFromWindow(hWnd, MONITOR_DEFAULTTONEAREST);

	// ��ȡ�������߼�������߶�
	MONITORINFOEX miex;
	miex.cbSize = sizeof(miex);
	GetMonitorInfo(hMonitor, &miex);
	int cxLogical = (miex.rcMonitor.right - miex.rcMonitor.left);
	int cyLogical = (miex.rcMonitor.bottom - miex.rcMonitor.top);

	// ��ȡ����������������߶�
	DEVMODE dm;
	dm.dmSize = sizeof(dm);
	dm.dmDriverExtra = 0;
	EnumDisplaySettings(miex.szDevice, ENUM_CURRENT_SETTINGS, &dm);
	int cxPhysical = dm.dmPelsWidth;
	int cyPhysical = dm.dmPelsHeight;

	//���ű�������
	*horzScale = ((double)cxPhysical / (double)cxLogical);
	*vertScale = ((double)cyPhysical / (double)cyLogical);


}
LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{

	if (nCode == HC_ACTION)
	{
		MSLLHOOKSTRUCT* ms = (MSLLHOOKSTRUCT*)lParam;		// �����ͼ����������¼���Ϣ
		DWORD code = ms->mouseData;
		HookPackage pk = {false,code,wParam };

		if (pyhookProc) {
			__int64 call_next = pyhookProc(&pk);
		}
		if (code== WM_MOUSEWHEEL && wParam == WM_RBUTTONUP)
		{
			//����
		}
	}
	// ����Ϣ���ݸ��������е���һ������

	return CallNextHookEx(NULL, nCode, wParam, lParam);
}
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	__int64 call_next = 1;
	if (nCode == HC_ACTION)
	{
		KBDLLHOOKSTRUCT* ks = (KBDLLHOOKSTRUCT*)lParam;		// �����ͼ����������¼���Ϣ
		DWORD code = ks->vkCode;
		HookPackage pk = {true,code,wParam };

		if (pyhookProc) {
			__int64 call_next = pyhookProc(&pk);

		}
		if (keyCodeArrivedEvent && wParam == WM_KEYDOWN)
		{
	
			keyCode = code;
			SetEvent(keyCodeArrivedEvent);
		}
		// ����Ϣ���ݸ��������е���һ������
	}
	return CallNextHookEx(NULL, nCode, wParam, lParam);
}

extern "C" __declspec(dllexport) HHOOK registerEventHook(int keyHook, bool doRegister) {
	DWORD dwThreadId = 0;// GetCurrentThreadId();
	HINSTANCE h = NULL;
	//if (dwThreadId == 0)h = hInstance;
	if (keyHook)
	{
		if (doRegister)
		{
			g_Hook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, h, dwThreadId);
		}
		else {
			if (g_Hook)UnhookWindowsHookEx(g_Hook);
			g_Hook = NULL;
		}
		return g_Hook;


	}
	else {
		if (doRegister)
		{
			m_Hook = SetWindowsHookEx(WH_MOUSE_LL, LowLevelMouseProc, h, dwThreadId);
		}
		else {
			if (m_Hook)UnhookWindowsHookEx(m_Hook);
			m_Hook = NULL;
		}
		return m_Hook;

	}

}
extern "C" __declspec(dllexport) void myRedrawWindow(HWND hwnd,RECT * myRect) {
	
	RedrawWindow(hwnd, myRect, NULL, RDW_INVALIDATE| RDW_ERASE);//| RDW_UPDATENOW

}

extern "C" __declspec(dllexport) void setPyHookProc(PYHOOKPROC pyHookFunc) {
	pyhookProc = pyHookFunc;

}
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_SETCURSOR:
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		return TRUE;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		// ��͸�����������������
		//HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0)); // ����������ɫ��͸��ɫһ��
		//FillRect(hdc, &ps.rcPaint, hBrush);
		//DeleteObject(hBrush);

		if (pyPaintCallback) pyPaintCallback(hdc);
		
		/*
		// ���ơ�hello�� 
		// ����͸������
		SetBkMode(hdc, TRANSPARENT);

		// �����ı���ɫ
		SetTextColor(hdc, RGB(255, 0, 0));
		RECT rect;
		rect.left = 0;
		rect.top = 0;
		rect.bottom = 50;
		rect.right = 50;
		DrawTextA(hdc, "hello", -1, &rect, DT_CENTER| DT_VCENTER | DT_SINGLELINE );
		*/
		EndPaint(hwnd, &ps);
		return 0;
	}
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}
extern "C" __declspec(dllexport) HBITMAP Mat2HBitmap(int nChannels, int cols,int rows,UCHAR* data)
{
	HBITMAP hBmp;
	//MAT���TYPE=��nChannels-1+ CV_8U��<<3int nChannels=(mat.type()>>3)-CV_8U+1;

	int iSize = cols * rows * nChannels;
	hBmp = CreateBitmap(cols, rows, 1, nChannels * 8, data);
	/*size_t info[4];
	GetBmpInfo(hBmp, info);
	HDC hdc;
	hdc = GetDC(g_wnd);

	HDC mdc = CreateCompatibleDC(hdc);
	HBITMAP hOldBitmap = (HBITMAP)SelectObject(mdc, hBmp);
	BitBlt(hdc, 0, 0, cols, rows, mdc, 0, 0, SRCCOPY);
	
	LOGFONT fontRect;
	memset(&fontRect, 0, sizeof(LOGFONT));

	fontRect.lfHeight = 30; //����ĸ߶�
	fontRect.lfWeight = FW_HEAVY; //����Ĵ�ϸ
	lstrcpy(fontRect.lfFaceName, "����");
	HFONT hFont = CreateFontIndirect(&fontRect); //��������
	HFONT oldFont = (HFONT)SelectObject(hdc, hFont);

	TextOutA(hdc, 0, 0,"c����", 50);
	HFONT un_use_font = (HFONT)SelectObject(hdc, oldFont);
	DeleteObject(un_use_font);
	DeleteDC(mdc);
	DeleteObject(hOldBitmap);
	ReleaseDC(g_wnd, hdc);
	DeleteDC(hdc);*/

	return hBmp;
}
extern "C" __declspec(dllexport) void MyUpdateLayeredWindow(HWND hwnd,HDC hdc, HDC mdc, LONG width, LONG height) {

	POINT dcOffset = { 0, 0 };
	SIZE size = { 0, 0 };
	size.cx = width;
	size.cy = height;
	BLENDFUNCTION bf;
	bf.BlendOp = AC_SRC_OVER;
	bf.BlendFlags = 0;
	bf.SourceConstantAlpha = 255;
	bf.AlphaFormat = AC_SRC_ALPHA;
	UpdateLayeredWindow(hwnd, 0, 0, &size, hdc, &dcOffset, 0, &bf, ULW_ALPHA);
}
extern "C" __declspec(dllexport) void MySetWindowDisplayAffinity(HWND hwnd,DWORD  dwAffinity) {
	if (dwAffinity == 1) {
		SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);//ϵͳ��ͼʱ�������������
	}
	else if(dwAffinity==0)
	{
		SetWindowDisplayAffinity(hwnd, WDA_NONE);
	}
	else
	{
		SetWindowDisplayAffinity(hwnd, WDA_MONITOR);
	}

}

extern "C" __declspec(dllexport) void MySetWindowInterceptMode(HWND hwnd,bool userBlock)
{
	if (!hwnd) return;
	if (userBlock) { // �л�������ģʽ����ֹ��͸���������û������
		// �Ƴ� WS_EX_TRANSPARENT ��ʽ��ʹ���������ص��
		LONG_PTR exStyle = GetWindowLongPtr(hwnd, GWL_EXSTYLE);
		exStyle &= ~WS_EX_TRANSPARENT;
		SetWindowLongPtr(hwnd, GWL_EXSTYLE, exStyle);
		SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
		// ��ѡ���ı������ʾ�û���ǰ�ɽ���������ı�͸���ȣ�
		SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 128, LWA_ALPHA);
	}
	else // �л��ش�͸ģʽ�������ص���������͸���²㣩
	{
		// ���� WS_EX_TRANSPARENT ��ʽ��ʹ��괩͸
		LONG_PTR exStyle = GetWindowLongPtr(hwnd, GWL_EXSTYLE);
		exStyle |= WS_EX_TRANSPARENT;
		SetWindowLongPtr(hwnd, GWL_EXSTYLE, exStyle);
		SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
		// �ָ�ԭʼ���
		SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
	}
	


}
extern "C" __declspec(dllexport) HWND CreateTransparentWindow(int x,int y,int nWight,int nHeight,PAINT_CALLBACK callback)
{

	// ע�ᴰ����
	WNDCLASS wc = { 0 };
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;

	wc.lpfnWndProc = WindowProc;
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(NULL_BRUSH); // ʹ��͸������ NULL_BRUSH
	wc.lpszClassName = "TransparentWindow";
	pyPaintCallback = callback;
	RegisterClass(&wc);

	// ��������
	HWND hwnd = CreateWindowExA( 
		WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT, // ���ô���Ϊ͸�������ڶ���  
		wc.lpszClassName,
		"Transparent Window",
		WS_POPUP, // �ޱ߿򴰿�WS_POPUP
		x / horzScale, y / vertScale, nWight / horzScale, nHeight / vertScale,
		NULL, NULL, hInstance, NULL);

	if (!hwnd)
	{
		return NULL;
	}

	// ����͸����
	SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
	//SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);//ϵͳ��ͼʱ�������������
	//SetLayeredWindowAttributes(hwnd, 0, 255, 2);
	// ��ʾ����
	ShowWindow(hwnd, SW_SHOW);
	g_wnd = hwnd;

	return hwnd;
}

extern "C" __declspec(dllexport) int  MessageLoop() {
	MSG msg;
	
	while (GetMessage(&msg, g_wnd, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);

	};
	return 0;
}

//����ϣ����̬���ӿ��ļ��ڱ���ʱ���������������Ʋ�Ҫ�����仯��Ϊ��ʵ����һĿ�ģ������ٶ��嵼������ʱ�����޶�����extern ��C��

extern "C" __declspec(dllexport) void  MyMoveWindow(HWND hwnd, RECT * myRect,bool bRepaint)
{

	RECT rect;
	rect.left = myRect->left / horzScale;
	rect.top = myRect->top / vertScale;
	rect.right  = myRect->right / horzScale;
	rect.bottom = myRect->bottom / vertScale;
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	MoveWindow(hwnd, rect.left, rect.top, w, h, bRepaint);


}

extern "C" __declspec(dllexport) RECT* GetWinRect(HWND hwnd, RECT* myRect)
{
	
	RECT rect;
	GetWindowRect(hwnd, &rect);
	//myRect[0] = rect.left * horzScale;
	//myRect[1] = rect.top * vertScale;
	//myRect[2] = rect.right * horzScale;
	//myRect[3] = rect.bottom * vertScale;
	myRect->left = rect.left * horzScale;
	myRect->top = rect.top * vertScale;
	myRect->right = rect.right * horzScale;
	myRect->bottom = rect.bottom* vertScale;
	return myRect;

}
extern "C" __declspec(dllexport) void MyGetCursorPos(int* x, int* y)
{
	POINT p;
	GetCursorPos(&p);
	*x = p.x* horzScale;
	*y = p.y* vertScale;

}

extern "C" __declspec(dllexport) void SimulateMouseMovement(int deltaX, int deltaY)
{
	INPUT input;
	input.type = INPUT_MOUSE;
	input.mi.dx = deltaX;
	input.mi.dy = deltaY;
	input.mi.mouseData = 0;
	input.mi.dwFlags = MOUSEEVENTF_MOVE;
	input.mi.time = 0;
	input.mi.dwExtraInfo = 0;

	SendInput(1, &input, sizeof(INPUT));
}

extern "C" __declspec(dllexport)  void SendKey(const char* keystr)
{
	/*for (int i = 0; i < strlen(keystr); i++)
	{
		char keyValue = keystr[i];
		//��ĸ A ����
		keybd_event(keyValue, 0, 0, 0);
		Sleep(100);
		keybd_event(keyValue, 0, KEYEVENTF_KEYUP, 0);

	}*/
	//ת��Ϊ���ֽ�ȷ��������ȷ��������
	int length = MultiByteToWideChar(CP_ACP, 0, keystr, -1, NULL, 0);
	wchar_t* wkeystr = new wchar_t[length];
	MultiByteToWideChar(CP_ACP, 0, keystr, -1, wkeystr, length);


	INPUT inputs[2];

	for (int i = 0; i < length - 1; ++i) {
		wchar_t aChar = wkeystr[i];

		// Press key
		inputs[0].type = INPUT_KEYBOARD;
		inputs[0].ki.wScan = aChar; // Unicode character
		inputs[0].ki.time = 0;
		inputs[0].ki.dwExtraInfo = 0;
		inputs[0].ki.wVk = 0; // Virtual-key code must be 0
		inputs[0].ki.dwFlags = KEYEVENTF_UNICODE;

		// Release key
		inputs[1].type = INPUT_KEYBOARD;
		inputs[1].ki.wScan = aChar; // Unicode character
		inputs[1].ki.time = 0;
		inputs[1].ki.dwExtraInfo = 0;
		inputs[1].ki.wVk = 0; // Virtual-key code must be 0
		inputs[1].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;

		// Send input
		SendInput(2, inputs, sizeof(INPUT));
	}

	delete[] wkeystr;

}

extern "C" __declspec(dllexport)  void MySetCursorPos(int middleX, int middleY)
{
	middleX = middleX / horzScale;
	middleY = middleY / vertScale;
	SetCursorPos(middleX, middleY);
	

}
void SendKeyByInput(bool down, char key) {

	INPUT input[2];

	// ���ð��¼��¼�
	input[0].type = INPUT_KEYBOARD;
	input[0].ki.wScan = 0;
	input[0].ki.time = 0;
	input[0].ki.dwExtraInfo = 0;
	input[0].ki.wVk = key; // ���ü�ֵ
	input[0].ki.dwFlags = 0; // 0 ��ʾ���¼�

	// �����ͷż��¼�
	input[1].type = INPUT_KEYBOARD;
	input[1].ki.wScan = 0;
	input[1].ki.time = 0;
	input[1].ki.dwExtraInfo = 0;
	input[1].ki.wVk = key; // ���ü�ֵ
	input[1].ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP ��ʾ�ͷż�
	if(down)
	// �����¼�
	SendInput(1, &input[0], sizeof(INPUT));
	else SendInput(1, &input[1], sizeof(INPUT));
}
extern "C" __declspec(dllexport)  void SendKeyDown(bool down, char key_code)
{
	//SendKeyByInput(down, key_code);
	//return;
	//���������ӳ��ؼ���ɨ����
	UINT scanCode = MapVirtualKeyEx(key_code, MAPVK_VK_TO_VSC, hkl);

	if (down) {
		keybd_event(key_code, scanCode, 0, 0); //KEYEVENTF_EXTENDEDKEY
	}
	else {
		keybd_event(key_code, scanCode, KEYEVENTF_KEYUP, 0);
	}

}
extern "C" __declspec(dllexport)  void ScrollMouse(int scroll_offset)
{
	mouse_event(MOUSEEVENTF_WHEEL, 0, 0, scroll_offset, 0);

}

extern "C" __declspec(dllexport)  void SendMouseDown(bool down,int buttonNum)
{
	if (down) {
		mouse_event(MOUSEEVENTF_LEFTDOWN << (2* buttonNum), 0, 0, 0, 0);
	}
	else {
		mouse_event(MOUSEEVENTF_LEFTUP << (2 * buttonNum), 0, 0, 0, 0);
	}

}

extern "C" __declspec(dllexport) DWORD WaitForKeyCodeEvent() {

	WaitForSingleObject(keyCodeArrivedEvent, INFINITE);
	ResetEvent(keyCodeArrivedEvent);
	return keyCode;
}

// �ص�����������ö�ٴ���
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
	char windowTitle[256];

	FindWinPackage* customPk = (FindWinPackage*)lParam;

	// ��ȡ���ڱ���
	if (GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle)) > 0) {
		if(strstr(windowTitle,customPk->winName)!=NULL){
			//printf("Window Title: %s\n", windowTitle);
			customPk->hwnd = hwnd;
			return FALSE; // ֹͣö��
		}
			
		
	}

	return TRUE; // ����ö����һ������
}

extern "C" __declspec(dllexport) HWND __stdcall MyFindWindow(const char* winName) {
	HWND hwnd;
	if (strlen(winName) <= 0) {
		hwnd = GetDesktopWindow();
	}
	else {
		hwnd = FindWindowA(NULL, winName);
		if (hwnd > 0) return hwnd;
		FindWinPackage pk = {0,winName };
		// ��ȡ���ھ��
		if (EnumWindows(EnumWindowsProc, (LPARAM)&pk)) {
			printf("Window enumeration completed.\n");
		}
		else {
			printf("Failed to enumerate windows.\n");
		}
		hwnd = pk.hwnd;

	}

	return hwnd;
}



extern "C" __declspec(dllexport) HDC MyGetWindowDC(HWND hwnd) {
	if (hwnd) return  GetWindowDC(hwnd);
	else return 0;
}

extern "C" __declspec(dllexport) size_t* GetBmpInfo(HBITMAP hBmp, size_t info[4]) {
	BITMAP Bmp;
	GetObject(hBmp, sizeof(BITMAP), &Bmp);
	size_t nChannels = Bmp.bmBitsPixel == 1 ? 1 : Bmp.bmBitsPixel / 8;

	info[0] = Bmp.bmWidth;
	info[1] = Bmp.bmHeight;
	info[2] = nChannels;
	info[3] = 8;//depth
	return info;
}
extern "C" __declspec(dllexport) void setTop(HWND hwnd, bool isTop)
{
	if (isTop) {
		// �ö�����
		SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);

	}
	else {

		// ȡ���ö�����HWND_NOTOPMOST���õ״���
		SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}
}
extern "C" __declspec(dllexport) void StartCapturewindow(HWND window_handle, MyFrameArrivedEventHandle myEventHandle) {
	DXGICapture::StartCapturewindow(window_handle, myEventHandle);

}
extern "C" __declspec(dllexport) void GetBmpData(HBITMAP hBmp, UCHAR * data) {
	BITMAP Bmp;
	GetObject(hBmp, sizeof(BITMAP), &Bmp);
	size_t nChannels = Bmp.bmBitsPixel == 1 ? 1 : Bmp.bmBitsPixel / 8;

	if (Bmp.bmWidth < 0 || Bmp.bmHeight < 0)
	{
		return;
	}

	if (data)
		GetBitmapBits(hBmp, Bmp.bmHeight * Bmp.bmWidth * nChannels, data);
	DeleteObject(hBmp);

}
extern "C" __declspec(dllexport) HWND __stdcall MyFindWindowByProcessId(unsigned long processId) {
	HWND windowHandle = nullptr;

	if (processId != 0) {
		// ��ȡ���ھ��
		windowHandle = FindWindow(nullptr, nullptr); // ���Ҷ��㴰��
		while (windowHandle) {
			DWORD windowProcessId;
			GetWindowThreadProcessId(windowHandle, &windowProcessId);
			if (windowProcessId == processId) {
				break; // �ҵ���Ӧ���̵Ĵ���
			}
			windowHandle = FindWindowEx(nullptr, windowHandle, nullptr, nullptr); // ������һ������
		}
	}
	return windowHandle;
}
extern "C" __declspec(dllexport) unsigned long __stdcall GetProcessIdFromProcessName(const char* procName) {

	DWORD processId = 0;

	// �������̿���
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (snapshot != INVALID_HANDLE_VALUE) {
		PROCESSENTRY32 processEntry;
		processEntry.dwSize = sizeof(PROCESSENTRY32);

		// �������̿���
		if (Process32First(snapshot, &processEntry)) {
			do {
				// ���������Ƿ�ƥ��
				if (strstr(processEntry.szExeFile, procName) != NULL) {
					processId = processEntry.th32ProcessID;
					break;
				}
			} while (Process32Next(snapshot, &processEntry));
		}

		CloseHandle(snapshot);


	}

	return processId;
}



extern "C" __declspec(dllexport) HBITMAP CopyScreenToBitmap(HWND hwnd, HDC hdc, RECT* myRect)
{
	HDC        hMemDC;
	// ��Ļ���ڴ��豸������
	HBITMAP   hBitmap, hOldBitmap;
	// λͼ���
	int  nX, nY, nX2, nY2;
	// ѡ����������
	int nWidth, nHeight;
	RECT rect;
	// ȷ��ѡ������Ϊ�վ���
	if (myRect == NULL)
		GetWindowRect(hwnd, &rect);
	else {
		rect.left = myRect->left;
		rect.top = myRect->top;
		rect.right = myRect->right;
		rect.bottom = myRect->bottom;

	}
	if (hdc == INVALID_HANDLE_VALUE || hdc == NULL) hdc = GetWindowDC(hwnd);
	//Ϊ��Ļ�����豸������



	//Ϊ��Ļ�豸�������������ݵ��ڴ��豸������
	hMemDC = CreateCompatibleDC(hdc);
	// ���ѡ����������
	nX = rect.left;
	nY = rect.top;
	nX2 = rect.right;
	nY2 = rect.bottom;


	//ȷ��ѡ�������ǿɼ���
	if (nX < 0)
		nX = 0;
	if (nY < 0)
		nY = 0;
	nWidth = nX2 - nX;
	nHeight = nY2 - nY;
	// ����һ������Ļ�豸���������ݵ�λͼ
	hBitmap = CreateCompatibleBitmap(hdc, nWidth, nHeight);
	if (hBitmap == NULL) {
		printf("bmp Null error code: %d\n", GetLastError());
		return NULL;
	}
	// ����λͼѡ���ڴ��豸��������
	hOldBitmap = (HBITMAP)SelectObject(hMemDC, hBitmap);
	// ����Ļ�豸�������������ڴ��豸��������
	BitBlt(hMemDC, 0, 0, nWidth, nHeight, hdc, nX, nY, SRCCOPY);
	hBitmap = (HBITMAP)SelectObject(hMemDC, hOldBitmap);


	DeleteDC(hMemDC);
	DeleteObject(hOldBitmap);

	return hBitmap;
}