#pragma once
#define DXCAPTRUE 
#ifdef DXCAPTRUE


#include<iostream>
#include <fstream>//ifstream���ļ���ofstreamд�ļ���fstream��д�ļ�
#include <vector>
#include<Windows.h>
#include <sstream>
#include <stdio.h>
#include <windows.h>

#include <io.h>
#include <process.h>
#include <d3d11.h>
#include <gdiplus.h>
#include <dxgi1_2.h>
#include <dxgi1_3.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <inspectable.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <Windows.Graphics.Capture.Interop.h>

#include <winrt/Windows.Foundation.Collections.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <roerrorapi.h>
#include <ShlObj_core.h>
#include <dwmapi.h>
#include <filesystem>

#pragma comment(lib, "Dwmapi.lib")
#pragma comment(lib, "windowsapp.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "gdiplus.lib")

namespace Gdiplus
{
	using std::min;
	using std::max;
};
typedef struct _PyImagePackage
{
	UCHAR* img_array;
	size_t height;
	size_t width;
	size_t rowPitch;
	size_t rSize;

} PyImagePackage;
typedef __int64 (*MyFrameArrivedEventHandle)(PyImagePackage* img_pk);

class DXGICapture
{
public:

	static int StartDXCaputreWindow(HWND gameWindow,  MyFrameArrivedEventHandle myEventHandle);
	static void StartCapturewindow(HWND window_handle, MyFrameArrivedEventHandle myEventHandle);

};

#endif


